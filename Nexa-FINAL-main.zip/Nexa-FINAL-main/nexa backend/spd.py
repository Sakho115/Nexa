from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
from datetime import datetime
import uuid

app = Flask(__name__)
CORS(app)

posts = []
users = {}

# --- IPFS Upload ---
def add_to_ipfs_file(file_data):
    files = {'file': file_data}
    try:
        res = requests.post("http://127.0.0.1:5001/api/v0/add", files=files)
        res.raise_for_status()
        return res.json()["Hash"]
    except Exception as e:
        print("Error uploading to IPFS:", e)
        return None

# --- Simulate DID Creation ---
def create_did():
    return f"did:nexa:{uuid.uuid4()}"

# --- Register User ---
@app.route("/api/register", methods=["POST"])
def register_user():
    username = request.json.get("username")
    if not username:
        return jsonify({"error": "Username is required"}), 400

    did = create_did()
    users[did] = {"username": username}
    return jsonify({"message": "User registered", "did": did}), 201

# --- Post to IPFS ---
@app.route("/api/post", methods=["POST"])
def post_to_ipfs():
    content = request.form.get("content", "")
    did = request.form.get("did")
    file = request.files.get("file")

    if not did or did not in users:
        return jsonify({"error": "Invalid or missing DID"}), 400

    if not content and not file:
        return jsonify({"error": "No content or file provided"}), 400

    if file:
        file_data = file.read()
        cid = add_to_ipfs_file(file_data)
    else:
        cid = add_to_ipfs_file(content.encode())

    if not cid:
        return jsonify({"error": "Failed to upload to IPFS"}), 500

    post = {
        "id": str(uuid.uuid4()),
        "did": did,
        "username": users[did]["username"],
        "cid": cid,
        "content": content,
        "timestamp": datetime.utcnow().isoformat()
    }
    posts.append(post)

    return jsonify({
        "message": "Post created and uploaded to IPFS",
        "post": post
    }), 201

# --- Get All Posts ---
@app.route("/api/posts", methods=["GET"])
def get_posts():
    return jsonify(posts), 200

@app.route("/")
def root():
    return "Welcome to the Nexa API server. Use /api endpoints for operations."

if __name__ == "__main__":
    app.run(debug=True, port=8000)
