import React, { createContext, useContext, useState } from 'react';
import { User, Post, Trend, NexaCoin } from '../types';
import { mockPosts, mockTrends, mockUsers } from '../data/mockData';
import { addPost, getNexaCoin, setNexaCoin } from '../utils/storage';

interface AppContextType {
  activePage: string;
  setActivePage: (page: string) => void;
  posts: Post[];
  setPosts: (posts: Post[]) => void;
  trends: Trend[];
  users: User[];
  nexaCoin: NexaCoin;
  createPost: (content: string, image?: string) => void;
  likePost: (postId: string) => void;
  tipUser: (userId: string, amount: number) => boolean;
}

const AppContext = createContext<AppContextType>({
  activePage: 'home',
  setActivePage: () => {},
  posts: [],
  setPosts: () => {},
  trends: [],
  users: [],
  nexaCoin: { balance: 0, earned: 0, spent: 0, history: [] },
  createPost: () => {},
  likePost: () => {},
  tipUser: () => false,
});

export const useApp = () => useContext(AppContext);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activePage, setActivePage] = useState('home');
  const [posts, setPosts] = useState<Post[]>(mockPosts);
  const [trends] = useState<Trend[]>(mockTrends);
  const [users] = useState<User[]>(mockUsers);
  const [nexaCoin, setNexaCoinState] = useState<NexaCoin>(getNexaCoin());

  const createPost = (content: string, image?: string) => {
    if (!content) return;
    
    const newPost: Post = {
      id: `post_${Date.now()}`,
      userId: 'guest',
      username: 'guest_user',
      displayName: 'Guest User',
      avatar: 'https://images.pexels.com/photos/1722198/pexels-photo-1722198.jpeg?auto=compress&cs=tinysrgb&w=600',
      content,
      image,
      likes: 0,
      comments: 0,
      reposts: 0,
      timestamp: new Date().toISOString(),
      isLiked: false,
    };
    
    const updatedPosts = [newPost, ...posts];
    setPosts(updatedPosts);
    addPost(newPost);

    // Earn some NEXA coins for posting
    const updatedCoin = { ...nexaCoin };
    updatedCoin.balance += 5;
    updatedCoin.earned += 5;
    updatedCoin.history.push({
      id: `tx_${Date.now()}`,
      amount: 5,
      type: 'earned',
      description: 'Posted new content',
      timestamp: new Date().toISOString(),
    });
    
    setNexaCoinState(updatedCoin);
    setNexaCoin(updatedCoin);
  };

  const likePost = (postId: string) => {
    const updatedPosts = posts.map(post => {
      if (post.id === postId) {
        const isLiked = !post.isLiked;
        return {
          ...post,
          likes: isLiked ? post.likes + 1 : post.likes - 1,
          isLiked,
        };
      }
      return post;
    });
    
    setPosts(updatedPosts);
  };

  const tipUser = (userId: string, amount: number): boolean => {
    if (nexaCoin.balance < amount) return false;
    
    // Update coin balance
    const updatedCoin = { ...nexaCoin };
    updatedCoin.balance -= amount;
    updatedCoin.spent += amount;
    updatedCoin.history.push({
      id: `tx_${Date.now()}`,
      amount,
      type: 'spent',
      description: `Tipped user ${userId}`,
      timestamp: new Date().toISOString(),
    });
    
    setNexaCoinState(updatedCoin);
    setNexaCoin(updatedCoin);
    return true;
  };

  return (
    <AppContext.Provider value={{
      activePage,
      setActivePage,
      posts,
      setPosts,
      trends,
      users,
      nexaCoin,
      createPost,
      likePost,
      tipUser,
    }}>
      {children}
    </AppContext.Provider>
  );
};