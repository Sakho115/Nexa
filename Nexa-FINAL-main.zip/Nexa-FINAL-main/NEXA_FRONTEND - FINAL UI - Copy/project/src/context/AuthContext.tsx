import React, { createContext, useContext, useEffect, useState } from 'react';
import { User } from '../types';
import { clearCurrentUser, getCurrentUser, setCurrentUser } from '../utils/storage';
import { defaultUser } from '../data/mockData';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  signup: (username: string, password: string, displayName: string) => Promise<boolean>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isAuthenticated: false,
  login: async () => false,
  signup: async () => false,
  logout: () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const storedUser = getCurrentUser();
    if (storedUser) {
      setUser(storedUser);
      setIsAuthenticated(true);
    }
  }, []);

  const login = async (username: string, password: string): Promise<boolean> => {
    // In a real app, this would make an API call to validate credentials
    if (username && password) {
      // Simulate successful login
      const newUser = {
        ...defaultUser,
        id: `user_${Date.now()}`,
        username,
        displayName: username,
      };
      
      setUser(newUser);
      setCurrentUser(newUser);
      setIsAuthenticated(true);
      return true;
    }
    return false;
  };

  const signup = async (username: string, password: string, displayName: string): Promise<boolean> => {
    // In a real app, this would make an API call to create a user
    if (username && password && displayName) {
      // Simulate successful signup
      const newUser = {
        ...defaultUser,
        id: `user_${Date.now()}`,
        username,
        displayName,
      };
      
      setUser(newUser);
      setCurrentUser(newUser);
      setIsAuthenticated(true);
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    clearCurrentUser();
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
};