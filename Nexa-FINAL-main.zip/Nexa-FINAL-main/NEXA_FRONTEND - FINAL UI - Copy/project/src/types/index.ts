export interface User {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  bio: string;
  followers: number;
  following: number;
  posts: number;
  joinedDate: string;
}

export interface Post {
  id: string;
  userId: string;
  username: string;
  displayName: string;
  avatar: string;
  content: string;
  image?: string;
  likes: number;
  comments: number;
  reposts: number;
  timestamp: string;
  isLiked?: boolean;
}

export interface Trend {
  id: string;
  topic: string;
  category: string;
  postCount: number;
}

export interface NexaCoin {
  balance: number;
  earned: number;
  spent: number;
  history: Array<{
    id: string;
    amount: number;
    type: 'earned' | 'spent';
    description: string;
    timestamp: string;
  }>;
}