import { Post, Trend, User } from '../types';

export const mockUsers: User[] = [
  {
    id: "1",
    username: "satoshi",
    displayName: "Satoshi Nakamoto",
    avatar: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=600",
    bio: "Creator of Bitcoin. Decentralization enthusiast.",
    followers: 2100000,
    following: 21,
    posts: 1024,
    joinedDate: "2009-01-03"
  },
  {
    id: "2",
    username: "vitalik",
    displayName: "Vitalik Buterin",
    avatar: "https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=600",
    bio: "Ethereum co-founder. Building decentralized future.",
    followers: 1500000,
    following: 512,
    posts: 4096,
    joinedDate: "2013-12-01"
  },
  {
    id: "3",
    username: "ada_lovelace",
    displayName: "Ada Lovelace",
    avatar: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=600",
    bio: "The first computer programmer. Web3 enthusiast.",
    followers: 987000,
    following: 42,
    posts: 314,
    joinedDate: "2019-10-15"
  }
];

export const mockPosts: Post[] = [
  {
    id: "1",
    userId: "1",
    username: "satoshi",
    displayName: "Satoshi Nakamoto",
    avatar: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=600",
    content: "Just released a new paper on a peer-to-peer electronic cash system. #Bitcoin #Decentralization",
    likes: 21000,
    comments: 1024,
    reposts: 5000,
    timestamp: "2009-01-03T18:15:00Z",
    isLiked: false
  },
  {
    id: "2",
    userId: "2",
    username: "vitalik",
    displayName: "Vitalik Buterin",
    avatar: "https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=600",
    content: "Smart contracts are the future of decentralized applications. What are you building on Ethereum today?",
    image: "https://images.pexels.com/photos/8369619/pexels-photo-8369619.jpeg?auto=compress&cs=tinysrgb&w=600",
    likes: 15600,
    comments: 982,
    reposts: 4231,
    timestamp: "2022-05-12T09:30:00Z",
    isLiked: true
  },
  {
    id: "3",
    userId: "3",
    username: "ada_lovelace",
    displayName: "Ada Lovelace",
    avatar: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=600",
    content: "The analytical engine weaves algebraic patterns just as the Jacquard loom weaves flowers and leaves. #Web3 #Programming",
    likes: 9870,
    comments: 543,
    reposts: 2100,
    timestamp: "2022-10-10T14:25:00Z",
    isLiked: false
  },
  {
    id: "4",
    userId: "1",
    username: "satoshi",
    displayName: "Satoshi Nakamoto",
    avatar: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=600",
    content: "NEXA is the future of decentralized social media. No central authority, no censorship, just pure connection.",
    image: "https://images.pexels.com/photos/2653362/pexels-photo-2653362.jpeg?auto=compress&cs=tinysrgb&w=600",
    likes: 18900,
    comments: 755,
    reposts: 3200,
    timestamp: "2022-11-15T10:45:00Z",
    isLiked: true
  }
];

export const mockTrends: Trend[] = [
  {
    id: "1",
    topic: "#Decentralization",
    category: "Technology",
    postCount: 58900
  },
  {
    id: "2",
    topic: "#Web3",
    category: "Technology",
    postCount: 42300
  },
  {
    id: "3",
    topic: "#NexaCoin",
    category: "Cryptocurrency",
    postCount: 35600
  },
  {
    id: "4",
    topic: "#DeFi",
    category: "Finance",
    postCount: 29800
  },
  {
    id: "5",
    topic: "#NFTs",
    category: "Art",
    postCount: 24700
  }
];

export const defaultUser: User = {
  id: "guest",
  username: "guest_user",
  displayName: "Guest User",
  avatar: "https://images.pexels.com/photos/1722198/pexels-photo-1722198.jpeg?auto=compress&cs=tinysrgb&w=600",
  bio: "NEXA user exploring decentralized social media.",
  followers: 0,
  following: 0,
  posts: 0,
  joinedDate: new Date().toISOString().split('T')[0]
};