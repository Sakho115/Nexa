import React from 'react';
import { Search, Edit, Phone, Video } from 'lucide-react';
import { mockUsers } from '../data/mockData';

const MessagesPage: React.FC = () => {
  return (
    <div className="h-screen flex flex-col">
      <div className="sticky top-0 z-10 bg-[#0b0b0b]/80 backdrop-blur-md p-4 border-b border-[#1a1a1a]">
        <h1 className="text-xl font-bold">Messages</h1>
      </div>
      
      <div className="flex-1 flex overflow-hidden">
        {/* Contacts sidebar */}
        <div className="w-full sm:w-80 border-r border-[#1a1a1a] overflow-y-auto">
          <div className="p-3">
            <div className="relative">
              <input
                type="text"
                placeholder="Search messages"
                className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-full py-2 pl-9 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00f0ff] focus:shadow-[0_0_8px_rgba(0,240,255,0.3)]"
              />
              <Search className="absolute left-3 top-2.5 text-gray-500 w-4 h-4" />
            </div>
          </div>
          
          <div className="pt-2">
            {mockUsers.map(user => (
              <div 
                key={user.id}
                className="flex items-center p-3 hover:bg-[#121212] cursor-pointer"
              >
                <div className="relative">
                  <img 
                    src={user.avatar} 
                    alt={user.displayName}
                    className="w-12 h-12 rounded-full object-cover border border-[#2a2a2a]"
                  />
                  <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-[#0b0b0b] rounded-full"></span>
                </div>
                
                <div className="ml-3 flex-1 min-w-0">
                  <div className="flex justify-between items-baseline">
                    <h3 className="font-medium truncate">{user.displayName}</h3>
                    <span className="text-xs text-gray-400">2m</span>
                  </div>
                  <p className="text-gray-400 text-sm truncate">
                    {user.username === 'satoshi' 
                      ? 'Hey! Have you tried the new NEXA feature?'
                      : user.username === 'vitalik'
                      ? 'What do you think about the latest update?'
                      : 'Let me know when you\'re free to discuss'}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Chat area */}
        <div className="hidden sm:flex flex-1 flex-col bg-[#0e0e0e]">
          <div className="border-b border-[#1a1a1a] p-3 flex justify-between items-center">
            <div className="flex items-center">
              <img 
                src={mockUsers[0].avatar} 
                alt={mockUsers[0].displayName}
                className="w-10 h-10 rounded-full object-cover border border-[#2a2a2a]"
              />
              <div className="ml-3">
                <h3 className="font-medium">{mockUsers[0].displayName}</h3>
                <p className="text-xs text-green-500">Online</p>
              </div>
            </div>
            
            <div className="flex space-x-3 text-gray-400">
              <button className="p-2 rounded-full hover:bg-[#1a1a1a] transition-colors">
                <Phone className="w-5 h-5" />
              </button>
              <button className="p-2 rounded-full hover:bg-[#1a1a1a] transition-colors">
                <Video className="w-5 h-5" />
              </button>
            </div>
          </div>
          
          <div className="flex-1 p-4 overflow-y-auto">
            <div className="space-y-4">
              <div className="flex items-end">
                <img 
                  src={mockUsers[0].avatar} 
                  alt={mockUsers[0].displayName}
                  className="w-8 h-8 rounded-full object-cover mr-2"
                />
                <div className="bg-[#1a1a1a] max-w-xs rounded-2xl rounded-bl-none p-3">
                  <p className="text-white">Hey! Have you tried the new NEXA feature?</p>
                  <p className="text-xs text-gray-400 mt-1">10:24 AM</p>
                </div>
              </div>
              
              <div className="flex items-end justify-end">
                <div className="bg-gradient-to-r from-[#00f0ff]/20 to-[#bf00ff]/20 max-w-xs rounded-2xl rounded-br-none p-3">
                  <p className="text-white">Not yet, which one?</p>
                  <p className="text-xs text-gray-400 mt-1">10:26 AM</p>
                </div>
              </div>
              
              <div className="flex items-end">
                <img 
                  src={mockUsers[0].avatar} 
                  alt={mockUsers[0].displayName}
                  className="w-8 h-8 rounded-full object-cover mr-2"
                />
                <div className="bg-[#1a1a1a] max-w-xs rounded-2xl rounded-bl-none p-3">
                  <p className="text-white">The NEXA Coin tipping system! You can now reward creators directly.</p>
                  <p className="text-xs text-gray-400 mt-1">10:28 AM</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="p-3 border-t border-[#1a1a1a]">
            <div className="relative">
              <input
                type="text"
                placeholder="Type a message..."
                className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-full py-3 px-4 pr-12 text-white placeholder-gray-500 focus:outline-none focus:border-[#00f0ff] focus:shadow-[0_0_8px_rgba(0,240,255,0.3)]"
              />
              <button className="absolute right-3 top-3 text-[#00f0ff]">
                <Edit className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
        
        {/* Empty state for mobile */}
        <div className="flex-1 flex items-center justify-center bg-[#0e0e0e] sm:hidden">
          <div className="text-center p-6">
            <p className="text-lg text-gray-300">Select a conversation</p>
            <p className="text-sm text-gray-500 mt-1">Choose from your existing conversations</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MessagesPage;