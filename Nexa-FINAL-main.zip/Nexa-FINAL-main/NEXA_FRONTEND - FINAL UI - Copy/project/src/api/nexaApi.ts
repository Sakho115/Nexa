import axios from "axios";

const API_BASE_URL = "http://127.0.0.1:8000/api";

export const registerUser = async (username: string) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/register`, { username });
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const createPost = async (did: string, content: string, file?: File) => {
  try {
    const formData = new FormData();
    formData.append("did", did);
    formData.append("content", content);
    if (file) {
      formData.append("file", file);
    }
    const response = await axios.post(`${API_BASE_URL}/post`, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const getPosts = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/posts`);
    return response.data;
  } catch (error) {
    throw error;
  }
};
